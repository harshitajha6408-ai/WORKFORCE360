WORKFORCEHUB — SAMPLE WEBSITE

How to open:
1. Download and extract the ZIP folder.
2. Open the extracted folder.
3. Double-click index.html. It should open in Chrome, Edge, Safari, or another browser.
4. Use the left sidebar to explore Overview, Workers, Shift tracking, Safety reports, Payslips, and Skill passport.

Interactive demo:
- Add a worker from the Workers page or the Overview.
- Record a sample check-in from Shift tracking (use a worker name or ID from the directory).
- Create a safety report and mark it resolved.
- Add a training record in Skill passport.
- Print the sample payslip.

Important:
- This is a front-end student prototype using fictional sample data.
- Data changes exist only in the open browser session; there is no database or real login.
- QR/GPS verification, real payroll, voice services, notifications, and secure accounts are not implemented.
- Google Fonts requires an internet connection; the site still works with fallback fonts.
- Do not enter real worker, salary, location, or safety information.
